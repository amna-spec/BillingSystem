import sqlite3

# Connect to the database (or create if it doesn't exist)
conn = sqlite3.connect("billing_system.db")
cursor = conn.cursor()

# 1️⃣ Flats Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Flats (
  FlatNo VARCHAR(50) PRIMARY KEY,
  Location VARCHAR(255)
);
""")

# 2️⃣ Users Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Users (
  PersonID INTEGER PRIMARY KEY,
  Name VARCHAR(255),
  FlatNo VARCHAR(50) REFERENCES Flats(FlatNo) ON DELETE SET NULL,
  UserType VARCHAR(20) DEFAULT 'Residential',
  AutoClassification VARCHAR(20) CHECK (AutoClassification IN ('Protected', 'Unprotected')) DEFAULT NULL,
  ManualClassification VARCHAR(20) CHECK (ManualClassification IN ('Protected', 'Unprotected')) DEFAULT NULL,       
  LoadSanctioned FLOAT,
  Phase VARCHAR(10) CHECK (Phase IN ('1-Phase', '3-Phase'))
);
""")

# 3️⃣ User Classification Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS UserClassification (
  ClassificationID INTEGER PRIMARY KEY AUTOINCREMENT,
  PersonID INTEGER REFERENCES Users(PersonID) ON DELETE SET NULL,
  FlatNo VARCHAR(50) REFERENCES Flats(FlatNo) ON DELETE SET NULL,
  ClassificationType VARCHAR(20) CHECK (ClassificationType IN ('Auto', 'Manual')),
  ClassificationValue VARCHAR(20) CHECK (ClassificationValue IN ('Protected', 'Unprotected')),
  UpdatedByAdmin INTEGER DEFAULT NULL,
  UpdateDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")

# 4️⃣ Tariff Slabs Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS TariffSlabs (
  SlabID INTEGER PRIMARY KEY AUTOINCREMENT,
  MinUnits INTEGER NOT NULL,
  MaxUnits INTEGER NOT NULL,
  RatePerUnit FLOAT NOT NULL,
  RateEffectiveDate DATE NOT NULL
);
""")
# 5️⃣ Surcharge Type Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS SurchargeType (
  SurchargeTypeID INTEGER PRIMARY KEY AUTOINCREMENT,
  TypeName VARCHAR(100) UNIQUE CHECK (TypeName IN ('Uniform Quarterly', 'Additional PHL', 'Fuel Charge'))
);
""")
# 6️⃣ Surcharge Table
cursor.execute("""
 CREATE TABLE IF NOT EXISTS Surcharge (
  SurchargeID INTEGER PRIMARY KEY AUTOINCREMENT,
  SurchargeTypeID INTEGER REFERENCES SurchargeType(SurchargeTypeID), 
  RatePerUnit FLOAT DEFAULT 0.0,
  UnitsFrom INTEGER CHECK (SurchargeTypeID = 1 OR UnitsFrom IS NULL), 
  UnitsTo INTEGER CHECK (SurchargeTypeID = 1 OR UnitsTo IS NULL), 
  EffectiveMonth DATE NOT NULL, 
  UNIQUE (SurchargeTypeID,EffectiveMonth, UnitsFrom, UnitsTo)  
);

 """)

# Reading-Surcharge Mapping Table
cursor.execute("""
  CREATE TABLE IF NOT EXISTS ReadingSurchargeMapping (
  ID INTEGER PRIMARY KEY AUTOINCREMENT,
  ReadingID INTEGER REFERENCES BillingReadings(ReadingID) ON DELETE CASCADE,
  SurchargeID INTEGER REFERENCES Surcharge(SurchargeID) ON DELETE CASCADE,
  BillingMonth DATE NOT NULL, 
  SurchargeAmount FLOAT DEFAULT 0 ,
  UNIQUE (ReadingID, SurchargeID, BillingMonth)
);           
   """)
#SurchargeGSTDuty
cursor.execute("""
   CREATE TABLE IF NOT EXISTS SurchargeGSTDuty (
  ID INTEGER PRIMARY KEY AUTOINCREMENT,
  ReadingID INTEGER REFERENCES BillingReadings(ReadingID) ON DELETE CASCADE,
  TotalSurcharge FLOAT DEFAULT 0 CHECK (TotalSurcharge >= 0),
  GSTID INTEGER REFERENCES GSTRates(GSTID) ON DELETE SET NULL,
  ElectricDutyID INTEGER REFERENCES ElectricDutyRates(DutyID) ON DELETE SET NULL,
  GSTAmount FLOAT DEFAULT 0,  -- GST on Total Surcharge
  ElectricDutyAmount FLOAT DEFAULT 0,  -- Electric Duty on Total Surcharge
  UNIQUE (ReadingID)
);
               
 """)

# 5️⃣ GST Rates Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS GSTRates (
  GSTID INTEGER PRIMARY KEY AUTOINCREMENT,
  EffectiveDate DATE UNIQUE DEFAULT CURRENT_DATE,
  GST FLOAT NOT NULL CHECK (GST >= 0)
);
""")

# 6️⃣ Electric Duty Rates Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS ElectricDutyRates (
  DutyID INTEGER PRIMARY KEY AUTOINCREMENT,
  EffectiveDate DATE UNIQUE DEFAULT CURRENT_DATE,
  ElectricDuty FLOAT NOT NULL CHECK (ElectricDuty >= 0)
);
""")

# 7️⃣ Billing Readings Table
cursor.execute("""
  CREATE TABLE IF NOT EXISTS BillingReadings (
  ReadingID INTEGER PRIMARY KEY AUTOINCREMENT,
  FlatNo VARCHAR(50) REFERENCES Flats(FlatNo) ON DELETE SET NULL,
  BillingMonth DATE DEFAULT (DATE('now', 'start of month')),
  ReadingDate DATE DEFAULT (DATE('now')),
  PreviousReading FLOAT DEFAULT 0.0 NOT NULL,
  PresentReading FLOAT DEFAULT 0.0 NOT NULL,
  UnitsConsumed FLOAT GENERATED ALWAYS AS (ABS(PresentReading - PreviousReading)) VIRTUAL,
  UnitsAdjusted FLOAT DEFAULT 0,
  CorrectionStatus VARCHAR(20) DEFAULT 'Original' CHECK (CorrectionStatus IN ('Original', 'Corrected'))
);
""")

#   Additional Charges Table
cursor.execute("""
  CREATE TABLE IF NOT EXISTS AdditionalCharges (
  ChargeID INTEGER PRIMARY KEY AUTOINCREMENT,
  ReadingID INTEGER REFERENCES BillingReadings(ReadingID) ON DELETE CASCADE,
  GSTID INTEGER REFERENCES GSTRates(GSTID) ON DELETE SET NULL,
  ElectricDutyID INTEGER REFERENCES ElectricDutyRates(DutyID) ON DELETE SET NULL,          
  UNIQUE (ReadingID) 
);
 """)           
# 8️⃣ Billing Charges Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS BillingCharges (
  BillID INTEGER PRIMARY KEY AUTOINCREMENT,
  ReadingID INTEGER REFERENCES BillingReadings(ReadingID) ON DELETE CASCADE,
  RatePerUnit FLOAT,
  VariableCharges FLOAT DEFAULT 0.0 NOT NULL,
  AdditionalChargeID INTEGER NOT NULL REFERENCES AdditionalCharges(ChargeID) ON DELETE CASCADE,           
  SurchargeGSTDutyID INTEGER NOT NULL REFERENCES SurchargeGSTDuty(ID) ON DELETE CASCADE, 
  TotalAdditionalCharges FLOAT DEFAULT 0.0 NOT NULL,
  TotalSurcharge FLOAT DEFAULT 0.0 NOT NULL, 
  NetPayableAmount FLOAT DEFAULT 0.0 NOT NULL, 
  BillGenerationDate TEXT DEFAULT (DATE('now')), 
  Status VARCHAR(20) CHECK (Status IN ('Paid', 'Unpaid', 'Due')),
  Remarks TEXT DEFAULT 'No remarks'
);
""")


# 9️⃣ Consumption History Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS ConsumptionHistory (
  ConsumptionID INTEGER PRIMARY KEY AUTOINCREMENT,
  PersonID INTEGER REFERENCES Users(PersonID) ON DELETE SET NULL,
  FlatNo VARCHAR(50) REFERENCES Flats(FlatNo) ON DELETE SET NULL,
  BillingMonth DATE NOT NULL,
  UnitsConsumed FLOAT,
  RecordedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")

# 🔟 Administrators Table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Administrators (
  AdminID INTEGER PRIMARY KEY AUTOINCREMENT,
  Name VARCHAR(255),
  Role VARCHAR(50)
);
""")

# Commit changes and close connection
conn.commit()
conn.close()

print("Database tables created successfully! ✅")